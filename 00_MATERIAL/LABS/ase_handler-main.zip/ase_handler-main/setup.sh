#!/bin/bash

WORKDIR="$(pwd)"
echo $WORKDIR

# if ufficial project is already installed
flaga=0
if [[ -d "../ase_riscv_gem5_sim" ]]; then
  flaga=1
fi

grep -qxF "export PATH=\"$WORKDIR:\$PATH\"" ~/.bashrc || {
  echo "export PATH=\"$WORKDIR:\$PATH\"" >> ~/.bashrc
}

cd ..
FATHERFIR="$(pwd)"
if [[ $flaga -eq 0 ]]; then
  git clone https://github.com/cad-polito-it/ase_riscv_gem5_sim.git
  sudo chmod -R +x ase_riscv_gem5_sim
  cd ase_riscv_gem5_sim
fi
# set env variable
grep -qxF 'export ASEMANAGEPROGRAM' ~/.bashrc || {
  echo "ASEMANAGEPROGRAM=\"$WORKDIR\"" >> ~/.bashrc
  echo 'export ASEMANAGEPROGRAM' >> ~/.bashrc
  echo "ASEDIR=\"$FATHERFIR/ase_riscv_gem5_sim\"" >> ~/.bashrc
  echo 'export ASEDIR' >> ~/.bashrc
}
source ~/.bashrc

if [[ $flaga -eq 0 ]]; then
  # substitute correct gem_visualizer-dep.sh
  cp -v "../ase_handler/base_files/gem-visualizer_dep.sh" "utils/Linux/Ubuntu/gem-visualizer_dep.sh"
  # launch script
  ./utils/installation.sh
fi

# install libraries for python script
# view doc https://packaging.python.org/en/latest/tutorials/installing-packages/#
python3 -m pip install --upgrade pip setuptools wheel
python3 -m pip install --upgrade pandas
python3 -m pip install --upgrade openpyxl

cd $WORKDIR
